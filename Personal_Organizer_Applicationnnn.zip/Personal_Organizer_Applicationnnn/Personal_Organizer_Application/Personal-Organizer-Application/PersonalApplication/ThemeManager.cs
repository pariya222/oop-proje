﻿using System.Drawing;
using System.Windows.Forms;

public static class ThemeManager
{
    // Ana renk paleti: Pembenin tonları
    public static Color PrimaryColor => Color.HotPink;    // #FF69B4
    public static Color SecondaryColor => Color.LightPink;  // #FFB6C1
    public static Color AccentColor => Color.DeepPink;   // #FF1493
    public static Color TextColor => Color.White;

    // Verilen kontrol ve tüm alt kontrolleri tema renkleriyle boyar
    public static void ApplyTheme(Control parent)
    {
        parent.BackColor = PrimaryColor;
        parent.ForeColor = TextColor;

        foreach (Control ctrl in parent.Controls)
        {
            // Menü / header gibi ayrı renk kullanmak isterseniz buraya if(ctrl is Panel panel) vs. ekleyebilirsiniz
            ApplyTheme(ctrl);
        }
    }
}
