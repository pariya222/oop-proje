﻿// MainForm.cs
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Personal_Organizer_Application
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            // Apply pink theme to main form
            ThemeManager.ApplyTheme(this);
            panelMenu.BackColor = ThemeManager.SecondaryColor;
            panelContent.BackColor = ThemeManager.SecondaryColor;
            // Menü butonlarındaki Image (Bitmap) ikonların rengini tema rengine göre değiştir:
            Button[] menuButtons = {
        btnPhoneBook,
        btnNoteBook,
        btnManagement,
        btnCalculator,
        btnReminder,
        
    };

            foreach (var btn in menuButtons)
            {
                if (btn.Image is Bitmap bmp)
                {
                    // Icon’ı pembeye çevir
                    btn.Image = TintBitmap(bmp, ThemeManager.TextColor);
                    // İkon solda, metin sağda gözüksün
                    btn.ImageAlign = ContentAlignment.MiddleLeft;
                    btn.TextImageRelation = TextImageRelation.ImageBeforeText;
                }
            }
        }

        private Bitmap TintBitmap(Bitmap src, Color targetColor)
        {
            var bmp = new Bitmap(src.Width, src.Height);
            using (var g = Graphics.FromImage(bmp))
            {
                // Renk vektörlerini normalize et
                float r = targetColor.R / 255f;
                float gco = targetColor.G / 255f;
                float b = targetColor.B / 255f;

                // Sıfır çarpanlarla orijinali görmezden gelip sadece translation satırını kullanıyoruz
                var cm = new System.Drawing.Imaging.ColorMatrix(new float[][]
                {
            new float[]{ 0,   0,   0, 0, r },  // R kanalını targetColor.R ile doldur
            new float[]{ 0,   0,   0, 0, gco}, // G kanalını targetColor.G ile doldur
            new float[]{ 0,   0,   0, 0, b },  // B kanalını targetColor.B ile doldur
            new float[]{ 0,   0,   0, 1, 0 },  // alpha kanalını olduğu gibi bırak
            new float[]{ 0,   0,   0, 0, 1 }
                });

                var ia = new System.Drawing.Imaging.ImageAttributes();
                ia.SetColorMatrix(cm,
                    System.Drawing.Imaging.ColorMatrixFlag.Default,
                    System.Drawing.Imaging.ColorAdjustType.Bitmap);

                g.DrawImage(src,
                    new Rectangle(0, 0, src.Width, src.Height),
                    0, 0, src.Width, src.Height,
                    GraphicsUnit.Pixel,
                    ia);
            }
            return bmp;
        }

        // Load a child form into the content panel and apply theme
        private void LoadChildForm(Form child)
        {
            panelContent.Controls.Clear();
            child.TopLevel = false;
            child.FormBorderStyle = FormBorderStyle.None;
            child.Dock = DockStyle.Fill;
            panelContent.Controls.Add(child);

            // Apply theme to the child form as well
            ThemeManager.ApplyTheme(child);
            child.BackColor = ThemeManager.PrimaryColor;

            child.Show();
        }

        private void btnPhoneBook_Click(object sender, EventArgs e)
            => LoadChildForm(new PhoneBook());

        private void btnNoteBook_Click(object sender, EventArgs e)
            => LoadChildForm(new NoteBook());

        private void btnManagement_Click(object sender, EventArgs e)
            => LoadChildForm(new Management());

        private void btnCalculator_Click(object sender, EventArgs e)
            => LoadChildForm(new SalaryCalculator());

        private void btnReminder_Click(object sender, EventArgs e)
            => LoadChildForm(new Reminder());

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            using (var login = new LoginForm())
            {
                login.ShowDialog();
            }
            this.Close();
        }

        private void panelContent_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
