﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;

namespace Personal_Organizer_Application
{
    /// <summary>
    /// Ortak yardımcı metodlar sınıfı
    /// </summary>
    public static class Util
    {
        /// <summary>Verilen metnin SHA256 hash değerini hex string olarak döner.</summary>
        public static string ComputeStringToSha256Hash(string plainText)
        {
            using (var sha256 = SHA256.Create())
            {
                var bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(plainText));
                var sb = new StringBuilder(bytes.Length * 2);
                foreach (var b in bytes)
                    sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }

        /// <summary>Email doğrulama (küçük harfli alias).</summary>
        public static bool isEmailValid(string email) => IsEmailValid(email);

        /// <summary>Email adresinin geçerli formata sahip olup olmadığını kontrol eder.</summary>
        private static readonly Regex EmailRegex = new Regex(
            @"^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.(com|org|net|edu|gov|mil|biz|info|mobi)(\.[A-Z]{2})?$",
            RegexOptions.IgnoreCase | RegexOptions.Compiled);
        public static bool IsEmailValid(string email)
            => !string.IsNullOrWhiteSpace(email) && EmailRegex.IsMatch(email);

        /// <summary>Dosya yolundaki resmi base64 string olarak döner.</summary>
        public static string ImageToBase64(string path)
        {
            try { return Convert.ToBase64String(File.ReadAllBytes(path)); }
            catch { return null; }
        }

        /// <summary>Base64 string'i Image nesnesine dönüştürür.</summary>
        public static Image Base64ToImage(string base64String)
        {
            if (string.IsNullOrWhiteSpace(base64String))
                return null;

            // data URI prefix varsa atla
            var comma = base64String.IndexOf(',');
            var pureBase64 = comma >= 0
                ? base64String.Substring(comma + 1)
                : base64String;

            // Temizlik: boşluk, satır sonu, tırnak
            pureBase64 = pureBase64.Trim().Trim('"').Replace("\r", "").Replace("\n", "");

            byte[] bytes;
            try { bytes = Convert.FromBase64String(pureBase64); }
            catch (FormatException fe)
            {
                Debug.WriteLine($"[Base64ToImage] Invalid Base64: {pureBase64.Substring(0, Math.Min(50, pureBase64.Length))}...");
                throw new ArgumentException("Base64 dizgesi geçerli bir görsel içermiyor.", fe);
            }

            using (var ms = new MemoryStream(bytes))
            {
                Image img;
                try { img = Image.FromStream(ms, false, true); }
                catch (ArgumentException ae)
                {
                    Debug.WriteLine($"[Base64ToImage] Stream byte count: {bytes.Length}, header: {string.Join(",", bytes.Take(8))}");
                    throw new ArgumentException("Stream geçerli bir resim verisine sahip değil.", ae);
                }
                var result = new Bitmap(img);
                img.Dispose();
                return result;
            }
        }

        /// <summary>Telefon rehberini CSV'den okur.</summary>
        public static void LoadPhoneBook(List<Phone> list, string path)
        {
            list.Clear();
            if (!File.Exists(path)) return;
            foreach (var line in File.ReadAllLines(path))
            {
                var cols = line.Split(',');
                if (cols.Length < 7) continue;
                list.Add(new Phone(cols[0], cols[1], cols[2], cols[3], cols[4], cols[5], cols[6]));
            }
        }

        /// <summary>Telefon rehberini CSV'ye yazar.</summary>
        public static void SavePhoneBook(List<Phone> list, string path)
        {
            File.WriteAllLines(path, list.Select(p => p.ToString()));
        }

        /// <summary>Not defterini CSV'ye yazar.</summary>
        public static void SaveNotebook(List<Notes> notes, string path)
        {
            var lines = notes.Select(n => $"{n.Username},{Regex.Escape(n.Note).Replace(",", "#")}");
            File.WriteAllLines(path, lines);
        }

        /// <summary>Not defterini CSV'den okur (geçerli kullanıcıya göre filtreler).</summary>
        public static List<Notes> LoadNotebook(string path)
        {
            var list = new List<Notes>();
            if (!File.Exists(path)) return list;
            foreach (var line in File.ReadAllLines(path))
            {
                var parts = line.Split(',');
                if (parts.Length < 2) continue;
                var user = parts[0];
                var note = Regex.Unescape(parts[1]).Replace("#", ",");
                if (LoginedUser.getInstance().UserGetSet.Username == user)
                    list.Add(new Notes(user, note));
            }
            return list;
        }

        /// <summary>Kullanıcı listesini CSV'den okur.</summary>
        public static void LoadCsv(List<User> users, string path)
        {
            users.Clear();
            if (!File.Exists(path)) return;
            foreach (var line in File.ReadAllLines(path))
            {
                var cols = line.Split(',');
                if (cols.Length < 11) continue;
                // toString formatında 11 alan: username,hash,,usertype,name,surname,phone,address,email,photo,salary
                users.Add(new User(
                    cols[0],         // username
                    cols[1],         // password hash
                    false,           // rememberMe (unused)
                    cols[3],         // usertypes
                    cols[4], cols[5], cols[6], cols[7],
                    cols[8], cols[9], cols[10]
                ));
            }
        }

        /// <summary>Kullanıcı listesini CSV'ye yazar.</summary>
        public static void SaveCsv(List<User> users, string path)
        {
            File.WriteAllLines(path, users.Select(u => u.toString()));
        }

        /// <summary>Hatırlatıcı listesini CSV'den okur.</summary>
        public static void LoadReminder(List<Alarm> list, string path)
        {
            list.Clear();
            if (!File.Exists(path)) return;
            foreach (var line in File.ReadAllLines(path))
            {
                var cols = line.Split(',');
                if (cols.Length < 6) continue;
                list.Add(new Alarm(cols[0], cols[1], cols[2], cols[3], cols[4], cols[5]));
            }
        }

        /// <summary>Hatırlatıcı listesini CSV'ye yazar.</summary>
        public static void SaveReminder(List<Alarm> list, string path)
        {
            File.WriteAllLines(path, list.Select(a => a.ToString()));
        }

        /// <summary>Formu sallar.</summary>
        public static void Shake(Form form)
        {
            var original = form.Location;
            var rnd = new Random();
            const int amplitude = 10;
            for (int i = 0; i < 70; i++)
            {
                form.Location = new Point(
                    original.X + rnd.Next(-amplitude, amplitude),
                    original.Y + rnd.Next(-amplitude, amplitude)
                );
                Thread.Sleep(5);
            }
            form.Location = original;
        }

        /// <summary>O anki hatırlatıcıyı tetikler.</summary>
        public static void RingAlarm()
        {
            LoadReminder(Alarm.alarmList, Reminder.path);
            var nowKey = DateTime.Now.ToString("d") + "," + DateTime.Now.ToString("T");
            foreach (var a in Alarm.alarmList)
            {
                if (nowKey == a.Day + "," + a.Time)
                {
                    if (Form.ActiveForm != null)
                    {
                        Shake(Form.ActiveForm);
                        Form.ActiveForm.Text = a.Summary;
                    }
                    break;
                }
            }
        }
    }
}
